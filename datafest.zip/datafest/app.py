"""
Future Wallet — Streamlit Dashboard
Premium dark-themed financial projection visualization.
Enhanced with full multi-currency support (Spec 2.1).
"""

import streamlit as st
import plotly.graph_objects as go
import plotly.express as px
import numpy as np
import pandas as pd

from engine import (
    run_scenarios, SimulationEngine, PetState, PET_EMOJI,
    CURRENCY_CONFIG, CurrencyEngine, AssetClass, LockType,
)

# ──────────────────────────────────────────────────────────────────────
# Page Config & Custom CSS
# ──────────────────────────────────────────────────────────────────────

st.set_page_config(
    page_title="Future Wallet | Financial Projection Engine",
    page_icon="💰",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap');

    .stApp { font-family: 'Inter', sans-serif; }

    /* ── Animated Hero ── */
    @keyframes shimmer {
        0%   { background-position: -200% center; }
        100% { background-position: 200% center; }
    }
    .hero-title {
        font-size: 3rem; font-weight: 800; letter-spacing: -0.03em; margin-bottom: 0;
        background: linear-gradient(90deg, #667eea, #764ba2, #f093fb, #667eea);
        background-size: 200% auto;
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        background-clip: text;
        animation: shimmer 4s linear infinite;
    }
    .hero-subtitle {
        font-size: 1.05rem; color: #94a3b8; margin-top: 4px; font-weight: 300;
        letter-spacing: 0.04em;
    }

    /* ── Glassmorphism Cards ── */
    .glass-card {
        background: rgba(30, 41, 59, 0.55);
        backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(148, 163, 184, 0.12); border-radius: 20px;
        padding: 24px; text-align: center;
        transition: transform 0.25s cubic-bezier(.4,0,.2,1), box-shadow 0.25s;
    }
    .glass-card:hover {
        transform: translateY(-6px) scale(1.02);
        box-shadow: 0 16px 48px rgba(102, 126, 234, 0.18);
    }
    .metric-card { /* legacy compat */
        background: rgba(30, 41, 59, 0.55);
        backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(148, 163, 184, 0.12); border-radius: 20px;
        padding: 24px; text-align: center;
        transition: transform 0.25s cubic-bezier(.4,0,.2,1), box-shadow 0.25s;
    }
    .metric-card:hover {
        transform: translateY(-6px) scale(1.02);
        box-shadow: 0 16px 48px rgba(102, 126, 234, 0.18);
    }
    .metric-value { font-size: 1.9rem; font-weight: 700; color: #f1f5f9; margin: 8px 0 4px 0; }
    .metric-label {
        font-size: 0.8rem; color: #64748b; text-transform: uppercase;
        letter-spacing: 0.1em; font-weight: 600;
    }
    .metric-icon { font-size: 1.8rem; }

    /* ── Section Headers with glow ── */
    .section-header {
        font-size: 1.4rem; font-weight: 700; color: #e2e8f0;
        margin: 2.5rem 0 1rem 0; padding-bottom: 0.5rem;
        border-bottom: 2px solid rgba(102, 126, 234, 0.3);
        text-shadow: 0 0 20px rgba(102, 126, 234, 0.15);
    }

    /* ── Animated Pet ── */
    @keyframes bounce { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-8px)} }
    @keyframes shake { 0%,100%{transform:rotate(0)} 25%{transform:rotate(-5deg)} 75%{transform:rotate(5deg)} }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }

    .pet-badge {
        display: inline-block; padding: 10px 24px; border-radius: 50px;
        font-size: 1.3rem; font-weight: 700; letter-spacing: 0.02em;
        box-shadow: 0 4px 20px rgba(0,0,0,0.3);
    }
    .pet-chill { background: linear-gradient(135deg, #10b981, #059669); color: white; animation: bounce 2s ease infinite; }
    .pet-content { background: linear-gradient(135deg, #3b82f6, #2563eb); color: white; animation: bounce 3s ease infinite; }
    .pet-worried { background: linear-gradient(135deg, #f59e0b, #d97706); color: white; animation: shake 0.5s ease infinite; }
    .pet-panic { background: linear-gradient(135deg, #ef4444, #dc2626); color: white; animation: shake 0.3s ease infinite; }
    .pet-dead { background: linear-gradient(135deg, #6b7280, #374151); color: white; animation: pulse 2s ease infinite; }

    .sidebar-header { font-size: 1.1rem; font-weight: 600; color: #cbd5e1; margin: 1rem 0 0.5rem 0; }

    .dag-box {
        background: linear-gradient(145deg, rgba(30,27,75,0.7), rgba(49,46,129,0.7));
        backdrop-filter: blur(12px);
        border: 1px solid rgba(139, 92, 246, 0.3); border-radius: 16px;
        padding: 20px; font-size: 0.85rem; color: #c4b5fd;
    }

    .precision-box {
        background: linear-gradient(145deg, rgba(5,46,22,0.7), rgba(6,78,59,0.7));
        backdrop-filter: blur(12px);
        border: 1px solid rgba(16, 185, 129, 0.3); border-radius: 16px;
        padding: 20px; font-size: 0.85rem; color: #6ee7b7;
    }

    /* ── Sticky KPI bar ── */
    .kpi-bar {
        position: sticky; top: 0; z-index: 999;
        background: rgba(15, 23, 42, 0.85);
        backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px);
        border-bottom: 1px solid rgba(100, 116, 139, 0.2);
        padding: 12px 24px; border-radius: 0 0 16px 16px;
        display: flex; justify-content: space-around; align-items: center;
        margin: -1rem -1rem 1.5rem -1rem;
    }
    .kpi-item { text-align: center; }
    .kpi-value { font-size: 1.2rem; font-weight: 700; color: #f1f5f9; }
    .kpi-label { font-size: 0.65rem; color: #64748b; text-transform: uppercase; letter-spacing: 0.1em; }

    div[data-testid="stMetric"] {
        background: rgba(30, 41, 59, 0.55);
        backdrop-filter: blur(16px); -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(148, 163, 184, 0.12);
        border-radius: 20px; padding: 16px 20px;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    div[data-testid="stMetric"]:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 30px rgba(102, 126, 234, 0.12);
    }

    /* ── Footer ── */
    .footer-bar {
        text-align: center; color: #475569; font-size: 0.75rem;
        padding: 2rem 0 1rem 0; border-top: 1px solid rgba(100,116,139,0.15);
        letter-spacing: 0.05em;
    }
</style>
""", unsafe_allow_html=True)

CURRENCY_OPTIONS = list(CURRENCY_CONFIG.keys())

# Helper to map pet state string to CSS class
def _pet_css(pet_str: str) -> str:
    for state in PetState:
        if state.value in pet_str:
            return {
                PetState.CHILL: "pet-chill", PetState.CONTENT: "pet-content",
                PetState.WORRIED: "pet-worried", PetState.PANIC: "pet-panic",
                PetState.DEAD: "pet-dead",
            }.get(state, "pet-content")
    return "pet-content"


# ──────────────────────────────────────────────────────────────────────
# Sidebar Inputs
# ──────────────────────────────────────────────────────────────────────

with st.sidebar:
    st.markdown("## ⚙️ Simulation Parameters")
    st.markdown("---")

    st.markdown('<p class="sidebar-header">💵 Income & Savings</p>', unsafe_allow_html=True)
    initial_savings = st.number_input("Initial Savings", 0, 1_000_000, 20_000, step=1000)
    monthly_salary = st.number_input("Monthly Salary", 0, 500_000, 5_000, step=500)

    st.markdown('<p class="sidebar-header">💱 Currency Configuration</p>', unsafe_allow_html=True)
    home_currency = st.selectbox("Home Currency", CURRENCY_OPTIONS, index=0,
                                  help="Primary denomination for balances & reporting")
    salary_currency = st.selectbox("Salary Currency", CURRENCY_OPTIONS, index=0,
                                    help="Currency your salary is paid in")
    expense_currency = st.selectbox("Expense Currency", CURRENCY_OPTIONS, index=0,
                                     help="Currency your expenses are denominated in")

    st.markdown('<p class="sidebar-header">💸 Expenses & Debt</p>', unsafe_allow_html=True)
    monthly_expenses = st.number_input("Monthly Expenses", 0, 200_000, 3_000, step=500)
    initial_debt = st.number_input("Total Debt", 0, 1_000_000, 15_000, step=1000)
    monthly_debt_payment = st.number_input("Monthly Debt Payment", 0, 50_000, 500, step=100)

    st.markdown('<p class="sidebar-header">⚡ Risk & Timeline</p>', unsafe_allow_html=True)
    shock_probability = st.slider("Shock Probability", 0.0, 0.20, 0.02, 0.005,
                                   format="%.3f",
                                   help="Daily probability of a financial shock event")
    simulation_years = st.slider("Simulation Horizon (Years)", 1, 30, 5)
    seed = st.number_input("Random Seed (Determinism)", 0, 999999, 42, step=1)

    st.markdown("---")
    run_button = st.button("🚀 **Run Simulation**", use_container_width=True, type="primary")


# ──────────────────────────────────────────────────────────────────────
# Header
# ──────────────────────────────────────────────────────────────────────

st.markdown('<h1 class="hero-title">Future Wallet</h1>', unsafe_allow_html=True)
st.markdown('<p class="hero-subtitle">High-Fidelity Financial Projection & Simulation Engine — DataFest\'26</p>',
            unsafe_allow_html=True)


# ──────────────────────────────────────────────────────────────────────
# Main Logic
# ──────────────────────────────────────────────────────────────────────

SCENARIO_COLORS = {
    "Optimistic": "#10b981", "Base Case": "#3b82f6", "Pessimistic": "#ef4444",
}
SCENARIO_FILLS = {
    "Optimistic": "rgba(16,185,129,0.08)", "Base Case": "rgba(59,130,246,0.08)",
    "Pessimistic": "rgba(239,68,68,0.08)",
}
SCENARIO_ICONS = {"Optimistic": "🟢", "Base Case": "🔵", "Pessimistic": "🔴"}

if run_button or "results" in st.session_state:
    if run_button:
        with st.spinner("⏳ Running deterministic simulation across 3 scenarios..."):
            results = run_scenarios(
                seed=seed,
                initial_savings=initial_savings,
                monthly_salary=monthly_salary,
                monthly_expenses=monthly_expenses,
                initial_debt=initial_debt,
                monthly_debt_payment=monthly_debt_payment,
                shock_probability=shock_probability,
                simulation_years=simulation_years,
                salary_currency=salary_currency,
                expense_currency=expense_currency,
                home_currency=home_currency,
            )
            st.session_state["results"] = results
            st.session_state["params"] = {
                "seed": seed, "home_currency": home_currency,
                "salary_currency": salary_currency, "expense_currency": expense_currency,
                "simulation_years": simulation_years,
            }
    else:
        results = st.session_state["results"]

    base = results["Base Case"]
    params = st.session_state.get("params", {})
    hc = params.get("home_currency", "USD")
    pet_class = _pet_css(base["pet_state"])

    # ── Sticky KPI Bar (Sits at the top of the content area) ──
    st.markdown(f"""
        <div class="kpi-bar">
            <div class="kpi-item">
                <div class="kpi-label">Final Balance</div>
                <div class="kpi-value">{base['final_balance']:,.0f} {hc}</div>
            </div>
            <div class="kpi-item">
                <div class="kpi-label">Credit Score</div>
                <div class="kpi-value">{base['credit_score']:.0f}</div>
            </div>
            <div class="kpi-item">
                <div class="kpi-label">Pet Status</div>
                <div class="kpi-value"><span class="pet-badge {pet_class}">{base['pet_state']}</span></div>
            </div>
            <div class="kpi-item">
                <div class="kpi-label">Financial Vibe</div>
                <div class="kpi-value">{base['vibe']}</div>
            </div>
        </div>
    """, unsafe_allow_html=True)

    # ── Main Dashboard Tabs ──
    tab_overview, tab_portfolio, tab_credit_tax, tab_scenarios = st.tabs([
        "🏠 Overview", "� Portfolio & Assets", "📊 Credit & Taxation", "🔮 What-If Analysis"
    ])

    with tab_overview:
        c1, c2, c3 = st.columns(3)
        with c1:
            st.markdown(f"""
            <div class="glass-card">
                <div class="metric-icon">💵</div>
                <div class="metric-label">Expected Balance</div>
                <div class="metric-value">{base['balance_expected']:,.0f} {hc}</div>
                <div style="font-size:0.75rem; color:#64748b;">95% CI: {base['balance_5th']:,.0f} — {base['balance_95th']:,.0f}</div>
            </div>
            """, unsafe_allow_html=True)
        with c2:
            st.markdown(f"""
            <div class="glass-card">
                <div class="metric-icon">🛡️</div>
                <div class="metric-label">Shock Resilience</div>
                <div class="metric-value">{base['rsi']:.1f}</div>
                <div style="font-size:0.75rem; color:#64748b;">RSI Score (0-100)</div>
            </div>
            """, unsafe_allow_html=True)
            st.markdown(f"""
            <div class="glass-card">
                <div class="metric-icon">⚠️</div>
                <div class="metric-label">Collapse Risk</div>
                <div class="metric-value">{base['collapse_probability']:.1%}</div>
                <div style="font-size:0.75rem; color:#64748b;">Prob. of bankruptcy</div>
            </div>
            """, unsafe_allow_html=True)

        # ── Gauge Charts Row ──
        st.markdown('<p class="section-header">🎯 Key Performance Indicators</p>', unsafe_allow_html=True)
        g1, g2, g3 = st.columns(3)
        with g1:
            fig_g1 = go.Figure(go.Indicator(
                mode="gauge+number", value=base['credit_score'], title={'text': "Credit Score"},
                gauge={'axis': {'range': [300, 850], 'tickwidth': 1}, 'bar': {'color': "#10b981"},
                       'steps': [{'range': [300, 580], 'color': "#ef4444"},
                                 {'range': [580, 670], 'color': "#f59e0b"},
                                 {'range': [670, 850], 'color': "#10b981"}]}))
            fig_g1.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", font={'family': "Inter"}, height=250, margin=dict(l=30, r=30, t=50, b=20))
            st.plotly_chart(fig_g1, use_container_width=True)
        with g2:
            fig_g2 = go.Figure(go.Indicator(
                mode="gauge+number", value=base['rsi'], title={'text': "Resilience (RSI)"},
                gauge={'axis': {'range': [0, 100]}, 'bar': {'color': "#3b82f6"},
                       'steps': [{'range': [0, 40], 'color': "#ef4444"},
                                 {'range': [40, 70], 'color': "#f59e0b"},
                                 {'range': [70, 100], 'color': "#10b981"}]}))
            fig_g2.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", font={'family': "Inter"}, height=250, margin=dict(l=30, r=30, t=50, b=20))
            st.plotly_chart(fig_g2, use_container_width=True)
        with g3:
            fig_g3 = go.Figure(go.Indicator(
                mode="gauge+number", value=base['liquidity_ratio']*100, title={'text': "Liquidity %"},
                gauge={'axis': {'range': [0, 100]}, 'bar': {'color': "#8b5cf6"}}))
            fig_g3.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", font={'family': "Inter"}, height=250, margin=dict(l=30, r=30, t=50, b=20))
            st.plotly_chart(fig_g3, use_container_width=True)

        st.markdown('<p class="section-header">📈 Projected Wealth Trajectory</p>', unsafe_allow_html=True)

        fig_wealth = go.Figure()
        for name, res in results.items():
            days = np.arange(len(res["daily_balances"]))
            fig_wealth.add_trace(go.Scatter(
                x=days, y=res["daily_balances"],
                name=f"{SCENARIO_ICONS.get(name, '')} {name}",
                line=dict(color=SCENARIO_COLORS.get(name, "#8b5cf6"), width=2),
                fill="tozeroy",
                fillcolor=SCENARIO_FILLS.get(name, "rgba(139,92,246,0.05)"),
            ))
        fig_wealth.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            height=500, margin=dict(l=20, r=20, t=40, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            xaxis_title="Day", yaxis_title=f"Cash Balance ({hc})",
            yaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            xaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            font=dict(family="Inter, sans-serif"),
        )
        st.plotly_chart(fig_wealth, use_container_width=True)

        # ── Recovery Slope Chart ──
        st.markdown('<p class="section-header">📉 Recovery Slope Analysis</p>', unsafe_allow_html=True)

        fig_recovery = go.Figure()
        for name, res in results.items():
            balances = np.array(res["daily_balances"])
            window = 30
            if len(balances) > window:
                slopes = []
                for i in range(window, len(balances)):
                    segment = balances[i - window:i]
                    x = np.arange(window)
                    slope = np.polyfit(x, segment, 1)[0]
                    slopes.append(slope)
                days = np.arange(window, len(balances))
                fig_recovery.add_trace(go.Scatter(
                    x=days, y=slopes, name=f"{SCENARIO_ICONS.get(name, '')} {name}",
                    line=dict(color=SCENARIO_COLORS.get(name), width=2),
                ))
        fig_recovery.add_hline(y=0, line_dash="dash", line_color="rgba(148,163,184,0.4)")
        fig_recovery.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            height=350, margin=dict(l=20, r=20, t=20, b=20),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
            xaxis_title="Day", yaxis_title=f"30-Day Rolling Slope ({hc}/day)",
            yaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            xaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            font=dict(family="Inter, sans-serif"),
        )
        st.plotly_chart(fig_recovery, use_container_width=True)


    # ── Credit Evolution Tab ──
    with tab_credit_tax:
        st.markdown('<p class="section-header">🏦 Credit Score History</p>', unsafe_allow_html=True)
        fig_credit = go.Figure()
        for name, res in results.items():
            days = np.arange(len(res["daily_credit_scores"]))
            fig_credit.add_trace(go.Scatter(
                x=days, y=res["daily_credit_scores"], name=name,
                line=dict(color=SCENARIO_COLORS.get(name), width=2),
            ))
        fig_credit.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            height=350, margin=dict(l=20, r=20, t=20, b=20),
            xaxis_title="Day", yaxis_title="Credit Score",
            yaxis=dict(range=[300, 850], gridcolor="rgba(100,116,139,0.15)"),
            xaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            font=dict(family="Inter, sans-serif"),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig_credit, use_container_width=True)


    with tab_portfolio:
        st.markdown('<p class="section-header">💎 Net Asset Value (NAV) & Composition</p>', unsafe_allow_html=True)

        fig_nav = go.Figure()
        for name, res in results.items():
            days = np.arange(len(res["daily_nav"]))
            fig_nav.add_trace(go.Scatter(
                x=days, y=res["daily_nav"], name=name,
                line=dict(color=SCENARIO_COLORS.get(name), width=2),
            ))
        fig_nav.update_layout(
            template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
            height=400, margin=dict(l=20, r=20, t=20, b=20),
            xaxis_title="Day", yaxis_title=f"NAV ({hc})",
            yaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            xaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
            font=dict(family="Inter, sans-serif"),
            legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        )
        st.plotly_chart(fig_nav, use_container_width=True)


        # ── Exchange Rate Dynamics (within tab_portfolio) ──
        st.markdown('<p class="section-header">💱 Exchange Rate Dynamics</p>', unsafe_allow_html=True)

        engine_fx = SimulationEngine(seed=params.get("seed", seed),
                                      simulation_years=params.get("simulation_years", simulation_years))
        rate_df = engine_fx.exchange_df
        fx_currencies = [c for c in rate_df.columns if c != "USD"]

        if fx_currencies:
            fx_tab1, fx_tab2 = st.tabs(["📈 Rate Trajectories", "📊 Volatility Heatmap"])

            with fx_tab1:
                fig_fx = go.Figure()
                fx_colors = ["#f59e0b", "#3b82f6", "#ef4444", "#10b981", "#8b5cf6"]
                for i, cur in enumerate(fx_currencies):
                    series = rate_df[cur].values
                    normalized = (series / series[0]) * 100
                    fig_fx.add_trace(go.Scatter(
                        x=np.arange(len(series)), y=normalized,
                        name=f"USD/{cur}",
                        line=dict(color=fx_colors[i % len(fx_colors)], width=2),
                    ))
                fig_fx.add_hline(y=100, line_dash="dash", line_color="rgba(148,163,184,0.3)")
                fig_fx.update_layout(
                    template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    height=380, margin=dict(l=20, r=20, t=20, b=20),
                    legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
                    xaxis_title="Day", yaxis_title="Indexed Rate (Base=100)",
                    yaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
                    xaxis=dict(gridcolor="rgba(100,116,139,0.15)"),
                    font=dict(family="Inter, sans-serif"),
                )
                st.plotly_chart(fig_fx, use_container_width=True)

            with fx_tab2:
                vol_data = {}
                for cur in fx_currencies:
                    returns = np.diff(np.log(rate_df[cur].values))
                    rolling_vol = pd.Series(returns).rolling(30).std() * np.sqrt(252) * 100
                    vol_data[cur] = rolling_vol.values
                vol_df = pd.DataFrame(vol_data).dropna()

                fig_heat = go.Figure(data=go.Heatmap(
                    z=vol_df.values.T, x=np.arange(len(vol_df)), y=fx_currencies,
                    colorscale="Inferno", colorbar=dict(title="Ann. Vol %"),
                ))
                fig_heat.update_layout(
                    template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    height=250, margin=dict(l=20, r=20, t=20, b=20),
                    xaxis_title="Day", yaxis_title="Currency",
                    font=dict(family="Inter, sans-serif"),
                )
                st.plotly_chart(fig_heat, use_container_width=True)

        # ── Precision Integrity Report (within tab_portfolio) ──
        with st.expander("🔬 Currency Conversion Precision Report", expanded=False):
            st.markdown('<div class="precision-box">', unsafe_allow_html=True)
            st.markdown("**Floating-Point Integrity across High-Frequency Conversions**")
            st.markdown(f"- Total Conversions: **{base.get('currency_conversions', 0):,}**")
            st.markdown(f"- Max Precision Drift: **{base.get('max_precision_drift', '0')}**")
            if base.get("wallet_balances"):
                st.markdown("**Final Wallet Balances:**")
                for cur, bal in base["wallet_balances"].items():
                    st.markdown(f"  - {cur}: **{bal:,.4f}**")
            if base.get("final_exchange_rates"):
                st.markdown("**Final Day Exchange Rates (vs USD):**")
                for cur, rate in base["final_exchange_rates"].items():
                    if cur != "USD":
                        st.markdown(f"  - USD/{cur}: **{rate:.6f}**")
            st.markdown('</div>', unsafe_allow_html=True)


        # ── Asset Portfolio Dashboard (within tab_portfolio) ──
        st.markdown('<p class="section-header">💼 Portfolio Composition & Liquidity</p>', unsafe_allow_html=True)

        pb = base.get("portfolio_breakdown", {})
        if pb:
            port_tab1, port_tab2, port_tab3 = st.tabs(
                ["📊 Asset Treemap", "📋 Asset Ledger", "🔻 Liquidation Events"]
            )

            with port_tab1:
                # Sunburst / Treemap of portfolio by class
                treemap_labels, treemap_values, treemap_parents, treemap_colors = [], [], [], []
                class_colors = {
                    "LIQUID": "#10b981", "YIELD": "#3b82f6",
                    "VOLATILE": "#f59e0b", "ILLIQUID": "#8b5cf6",
                }
                for cls_name, info in pb.items():
                    if info["count"] > 0:
                        treemap_labels.append(cls_name)
                        treemap_values.append(info["total_value"])
                        treemap_parents.append("")
                        treemap_colors.append(class_colors.get(cls_name, "#64748b"))
                        for a in info["assets"]:
                            treemap_labels.append(a["name"])
                            treemap_values.append(a["value"])
                            treemap_parents.append(cls_name)
                            treemap_colors.append(class_colors.get(cls_name, "#64748b"))

                fig_tree = go.Figure(go.Treemap(
                    labels=treemap_labels, values=treemap_values,
                    parents=treemap_parents,
                    marker=dict(colors=treemap_colors, line=dict(color="#0f172a", width=2)),
                    textinfo="label+value+percent parent",
                    textfont=dict(family="Inter, sans-serif"),
                ))
                fig_tree.update_layout(
                    template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)",
                    height=400, margin=dict(l=10, r=10, t=10, b=10),
                    font=dict(family="Inter, sans-serif"),
                )
                st.plotly_chart(fig_tree, use_container_width=True)

                # Summary metrics row
                m1, m2, m3, m4 = st.columns(4)
                with m1:
                    total_pv = sum(info["total_value"] for info in pb.values())
                    st.metric("Total Portfolio", f"{total_pv:,.0f} {hc}")
                with m2:
                    st.metric("Yield Earned", f"{base.get('total_yield_earned', 0):,.0f} {hc}")
                with m3:
                    liq = base.get("liquidation_summary", {})
                    st.metric("Liquidation Events", f"{liq.get('total_events', 0)}")
                with m4:
                    st.metric("Total Liquidated", f"{base.get('total_liquidated_value', 0):,.0f} {hc}")


        with port_tab2:
            # Detailed asset table
            asset_rows = []
            for cls_name, info in pb.items():
                for a in info["assets"]:
                    asset_rows.append({
                        "Asset": a["name"],
                        "Class": cls_name,
                        f"Value ({a['currency']})": f"{a['value']:,.2f}",
                        f"Cost Basis": f"{a['cost_basis']:,.2f}",
                        "Unrealized G/L": f"{a['unrealized_gain']:,.2f}",
                        "Yield Accrued": f"{a['accrued_yield']:,.2f}",
                        "Lock": a["lock_type"],
                        "Liquidations": a["liquidation_events"],
                    })
            if asset_rows:
                st.dataframe(pd.DataFrame(asset_rows), use_container_width=True, hide_index=True)

        with port_tab3:
            liq = base.get("liquidation_summary", {})
            if liq.get("total_events", 0) > 0:
                st.markdown(f"**Total Events:** {liq['total_events']} | "
                            f"**Proceeds:** {liq['total_proceeds']:,.0f} {hc} | "
                            f"**Penalties:** {liq['total_penalties']:,.0f} {hc} | "
                            f"**Lock Overrides:** {liq['lock_overrides']}")
                for cls, cinfo in liq.get("by_class", {}).items():
                    st.markdown(f"- **{cls}**: {cinfo['events']} events, "
                                f"{cinfo['proceeds']:,.0f} {hc} proceeds")
            else:
                st.success("No liquidation events triggered during this simulation. "
                           "Portfolio maintained positive liquidity throughout.")

        # ── Credit & Taxation Content (within tab_credit_tax) ──
        credit_factors = base.get("credit_factors", [])
        if credit_factors:
            cred_tab1, cred_tab2 = st.tabs(["📈 Score Trajectory", "🔍 Credit Factors"])
            with cred_tab1:
                fig_credit_evol = go.Figure()
                cf_days = [cf["day"] for cf in credit_factors]
                cf_scores = [cf["score"] for cf in credit_factors]
                fig_credit_evol.add_trace(go.Scatter(
                    x=cf_days, y=cf_scores, mode="lines+markers", fill="tozeroy",
                    line=dict(color="#10b981", width=2), marker=dict(size=4), name="Credit Score",
                ))
                fig_credit_evol.update_layout(
                    template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                    xaxis_title="Day", yaxis_title="Credit Score", yaxis=dict(range=[300, 850]),
                    height=350, margin=dict(l=50, r=20, t=30, b=40), font=dict(family="Inter, sans-serif"),
                )
                st.plotly_chart(fig_credit_evol, use_container_width=True)

            with cred_tab2:
                st.dataframe(pd.DataFrame(credit_factors), use_container_width=True, hide_index=True)

        tax_records = base.get("tax_records", [])
        tax_records = base.get("tax_records", [])
        if tax_records:
            st.markdown('<p class="section-header">🏦 Taxation Breakdown</p>', unsafe_allow_html=True)
            tax_tab1, tax_tab2 = st.tabs(["📊 Annual Tax Summary", "📋 Detailed Breakdown"])

            with tax_tab1:
                years = [f"Year {tr['year']}" for tr in tax_records]
                fig_tax = go.Figure()
                fig_tax.add_trace(go.Bar(x=years, y=[tr["income_tax"] for tr in tax_records], name="Income Tax", marker_color="#3b82f6"))
                fig_tax.add_trace(go.Bar(x=years, y=[tr["short_term_tax"] for tr in tax_records], name="Short-Term CG Tax", marker_color="#f59e0b"))
                fig_tax.add_trace(go.Bar(x=years, y=[tr["long_term_tax"] for tr in tax_records], name="Long-Term CG Tax", marker_color="#10b981"))
                fig_tax.add_trace(go.Bar(x=years, y=[tr["fx_tax"] for tr in tax_records], name="FX Tax", marker_color="#8b5cf6"))
                fig_tax.update_layout(barmode="stack", template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)", height=350, margin=dict(l=50, r=20, t=30, b=40), font=dict(family="Inter, sans-serif"), legend=dict(orientation="h", y=-0.2))
                st.plotly_chart(fig_tax, use_container_width=True)

                t1, t2, t3 = st.columns(3)
                with t1: st.metric("Total Tax Paid", f"{base.get('tax_paid', 0):,.0f} {hc}")
                with t2: st.metric("Unrealized Gains", f"{base.get('total_unrealized_gains', 0):,.0f} {hc}")
                with t3:
                    eff_rate = base.get("tax_paid", 0) / max(sum(tr["ordinary_income"] for tr in tax_records), 1)
                    st.metric("Effective Rate", f"{eff_rate:.1%}")

            with tax_tab2:
                tax_rows = [{"Year": tr["year"], f"Income ({hc})": f"{tr['ordinary_income']:,.0f}", f"ST Gains": f"{tr['short_term_gains']:,.0f}", f"LT Gains": f"{tr['long_term_gains']:,.0f}", f"Total Tax": f"{tr['total_tax']:,.0f}"} for tr in tax_records]
                st.dataframe(pd.DataFrame(tax_rows), use_container_width=True, hide_index=True)

        # ── Behavioral Metrics & DAG Summary (within tab_credit_tax) ──
        st.markdown('<p class="section-header">📡 Behavioral Metrics & Infrastructure</p>', unsafe_allow_html=True)
        dag_col, metrics_col = st.columns([1, 1])
        with dag_col:
            dag_info = base.get("dag_structure", {})
            if dag_info:
                st.markdown("##### 🧩 Component DAG")
                order = dag_info.get("order", [])
                for i, name in enumerate(order):
                    st.markdown(f"{'│ ' * i}├─ **{name}**")
        with metrics_col:
            st.markdown("##### 📡 Rolling Behavioral Metrics")
            st.metric("Shock Clustering", f"{base.get('rolling_scd', 0):.3f}")
            st.metric("Recovery Slope", f"{base.get('rolling_recovery', 1.0):.4f}")
            st.caption("Updated weekly; influences volatility sensitivity.")

    with dag_col:
        st.markdown("##### 🧩 Component DAG")
        dag_info = base.get("dag_structure", {})
        if dag_info:
            nodes = dag_info.get("nodes", [])
            edges = dag_info.get("edges", [])
            order = dag_info.get("order", [])

            node_icons = {
                "EXCHANGE": "💱", "INCOME": "💰", "EXPENSE": "💸",
                "TAX": "🏦", "ASSET_LIQUID": "📊", "ASSET_ILLIQUID": "🏠",
                "CREDIT": "📋",
            }

            for i, name in enumerate(order):
                node_info = next((n for n in nodes if n["name"] == name), None)
                if node_info:
                    icon = node_icons.get(node_info["type"], "⬡")
                    deps = node_info.get("deps", [])
                    dep_str = f" ← {', '.join(deps)}" if deps else ""
                    st.markdown(f"{'│ ' * i}├─ {icon} **{name}** `{node_info['type']}`{dep_str}")

            st.caption(f"v{dag_info.get('version', 0)} · "
                       f"{len(nodes)} nodes · {len(edges)} edges · "
                       f"{dag_info.get('changes', 0)} structural changes")

    with metrics_col:
        st.markdown("##### 📡 Rolling Behavioral Metrics")

        m1, m2 = st.columns(2)
        with m1:
            scd = base.get("rolling_scd", 0)
            scd_color = "🟢" if scd < 0.3 else "🟡" if scd < 0.6 else "🔴"
            st.metric(f"{scd_color} Shock Clustering", f"{scd:.3f}")

            recovery = base.get("rolling_recovery", 1.0)
            rec_color = "🟢" if recovery > 0.5 else "🟡" if recovery > 0 else "🔴"
            st.metric(f"{rec_color} Recovery Slope", f"{recovery:.4f}")

        with m2:
            vibe = base.get("rolling_vibe", "Neutral")
            pet = base.get("rolling_pet", "Content")
            vibe_icons = {"Chill": "😎", "Stable": "😃", "Uneasy": "😟",
                          "Stressed": "😰", "Critical": "💀"}
            st.metric(f"{vibe_icons.get(vibe, '🤖')} Vibe", vibe)
            st.metric(f"🐾 Pet State", pet)

        st.caption("Metrics update every 7 days and influence shock sensitivity + expense behavior")

    with tab_scenarios:
        # ── Scenario Comparison Table (consolidated) ──
        st.markdown('<p class="section-header">📋 Global Scenario Comparison</p>', unsafe_allow_html=True)
        table_data = []
        for name, res in results.items():
            table_data.append({
                "Scenario": f"{SCENARIO_ICONS.get(name, '')} {name}",
                f"Final Balance ({hc})": f"{res['final_balance']:,.0f}",
                "Collapse Prob": f"{res['collapse_probability']:.1%}",
                "Credit Score": f"{res['credit_score']:.0f}",
                "Shock Resilience": f"{res['rsi']:.1f}",
                "Pet State": res["pet_state"],
            })
        st.dataframe(pd.DataFrame(table_data), use_container_width=True, hide_index=True)

        # ── What-If Branching Demo ──
        st.markdown('<p class="section-header">🔀 What-If Branching</p>', unsafe_allow_html=True)
        st.markdown("Snapshot the simulation at a specific day and explore alternative futures.")

        with st.expander("🔮 Advanced Simulation Branching", expanded=True):
            branch_day = st.slider("Select Branch Point (Day)", 30, max(base["n_days"] - 30, 31), min(365, base["n_days"] // 2))

            bcol1, bcol2, bcol3 = st.columns(3)
            with bcol1: br_salary = st.number_input("Optimistic Salary Boost", monthly_salary, monthly_salary*3, monthly_salary+1000, key="br_sal")
            with bcol2: br_expenses = st.number_input("Pessimistic Expense Spike", monthly_expenses, monthly_expenses*3, monthly_expenses+500, key="br_exp")
            with bcol3: br_shock = st.slider("Shock Probability Target", 0.0, 0.2, 0.05, 0.01, key="br_shk")

            if st.button("🌿 Run Divergent Scenarios", use_container_width=True):
                with st.spinner("Generating alternative futures..."):
                    from engine import SimulationEngine as SE
                    # Base engine to reach branch point
                    eng = SE(seed=seed, initial_savings=initial_savings, monthly_salary=monthly_salary,
                             monthly_expenses=monthly_expenses, initial_debt=initial_debt,
                             monthly_debt_payment=monthly_debt_payment, shock_probability=shock_probability,
                             simulation_years=simulation_years, salary_currency=salary_currency,
                             expense_currency=expense_currency, home_currency=home_currency)

                    for d in range(branch_day): eng._step(d)
                    snap = eng.get_snapshot()

                    # Run branches
                    branches = eng.branch_scenarios({
                        "Optimistic (Salary ↑)": {"monthly_salary": br_salary, "shock_probability": 0.01},
                        "Pessimistic (Costs ↑)": {"monthly_expenses": br_expenses, "shock_probability": br_shock},
                        "Baseline Projection": {}
                    })
                    merged = SE.merge_branches(branches)

                    # Plotting Divergence
                    fig_div = go.Figure()
                    b_colors = {"Optimistic (Salary ↑)": "#10b981", "Pessimistic (Costs ↑)": "#ef4444", "Baseline Projection": "#3b82f6"}
                    for bname, bres in branches.items():
                        fig_div.add_trace(go.Scatter(y=bres["daily_balances"], name=bname, line=dict(color=b_colors.get(bname, "#888"), width=2)))
                    fig_div.add_vline(x=branch_day, line_dash="dash", line_color="#f59e0b", annotation_text="Branch Point")
                    fig_div.update_layout(template="plotly_dark", paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
                                          xaxis_title="Day", yaxis_title=f"Balance ({hc})", height=400, margin=dict(l=50, r=20, t=30, b=40))
                    st.plotly_chart(fig_div, use_container_width=True)

                    # Branch comparison table
                    comp_rows = []
                    for metric, mdata in merged["comparison"].items():
                        row = {"Metric": metric.replace("_", " ").title()}
                        for bname in merged["branch_names"]:
                            val = mdata["per_branch"].get(bname, 0)
                            row[bname] = f"{val:,.0f}" if isinstance(val, (int, float)) else str(val)
                        comp_rows.append(row)
                    st.dataframe(pd.DataFrame(comp_rows), use_container_width=True, hide_index=True)
                    st.success(f"🏆 Recommendation: **{merged.get('recommendation', 'Baseline')}** (Estimated best path)")


    # ── Footer ──
    st.markdown("---")
    st.markdown(
        '<p style="text-align:center; color:#64748b; font-size:0.8rem;">'
        'Future Wallet v2.0 — DataFest\'26 — Deterministic Financial Projection Engine — Multi-Currency Enabled'
        '</p>', unsafe_allow_html=True,
    )

else:
    # Landing state
    st.markdown("---")

    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-icon">🎯</div>
            <div class="metric-value">DAG</div>
            <div class="metric-label">Dependency Resolution</div>
        </div>
        """, unsafe_allow_html=True)
    with col2:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-icon">🔢</div>
            <div class="metric-value">Daily</div>
            <div class="metric-label">Granularity</div>
        </div>
        """, unsafe_allow_html=True)
    with col3:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-icon">💱</div>
            <div class="metric-value">6 FX</div>
            <div class="metric-label">Multi-Currency</div>
        </div>
        """, unsafe_allow_html=True)
    with col4:
        st.markdown("""
        <div class="metric-card">
            <div class="metric-icon">🔀</div>
            <div class="metric-value">Branch</div>
            <div class="metric-label">What-If Scenarios</div>
        </div>
        """, unsafe_allow_html=True)

    st.markdown("")
    st.info("👈 **Configure your parameters in the sidebar and click 'Run Simulation'** to start the deterministic projection engine.")

    with st.expander("📐 Architecture Overview"):
        st.markdown("""
        **Future Wallet** processes financial components as nodes in a **Directed Acyclic Graph (DAG)**:

        ```
        Exchange Rates → Income → Debt Service ──┐
                       → Expenses                │→ Credit Score Update
                       → Asset Valuation → Tax ──┘→ Liquidation Check
        ```

        **Multi-Currency Engine (Spec 2.1):**
        - **6 currencies** (USD, EUR, GBP, JPY, PKR, CHF) with correlated exchange rates
        - Ornstein-Uhlenbeck mean-reversion + Geometric Brownian Motion
        - Cholesky-decomposed correlation matrix for realistic co-movement
        - **Decimal-precision** conversions with round-trip integrity verification
        - Full conversion audit trail for compliance validation
        - Transaction-time realization: conversion at exact daily rate
        """)
